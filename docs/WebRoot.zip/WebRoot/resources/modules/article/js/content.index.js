﻿$(document).ready(function() {
	loadDataGridContent(columnsDefined(), 'formatData');

	/**
	 * 刷新或搜索
	 */
	$('body').delegate('.action-refresh, #action_search', 'click', function() {
		$('#content_listing').datagrid('reload');
	});

	/**
	 * 关键字搜索 - 支持回车
	 */
	$("input[name=key]").on('keypress', function(event) {
		if (event.which == '13') {
			$('#content_listing').datagrid('reload');
			return false;
		}
	});

	/**
	 * 单个删除
	 */
	$('#content_listing').delegate('.operate-delete', 'click', function() {
		var del = confirm('确定要删除吗？');
		if (!del) {
			return false;
		}
		
				var contentId = $(this).attr("contentId");
		
		/* 执行 */
		$.ajax({
			type : 'post',
			url : BASE_URL + '/articleContent/delete',
			data : 'contentId=' + contentId,
			dataType : 'json',
			timeout : 10000,
			success : function(data) {
				if (data.status == 0) {
					$("#contentId_" + contentId).parent().parent().remove();
				} else {
					alert(data.msg);
				}
				return false;
			}
		});
	});
});

function columnsDefined() {
	return [
				{
					property: '_query',
					label: ''
				},
				{
					property : 'contentId',
					label : '文章编号',
					sortable : false
				},
				{
					property : 'category_name',
					label : '分类名称',
					sortable : false
				},
				{
					property : 'image',
					label : '展示图',
					sortable : false
				},
				{
					property : 'title',
					label : '标题',
					sortable : false
				},
				{
					property : 'click',
					label : '点击量',
					sortable : false
				},
				{
					property : 'status',
					label : '发布状态',
					sortable : false
				},
				{
					property : 'mtime',
					label : '修改时间',
					sortable : false
				},
				{
					property : 'ctime',
					label : '创建时间',
					sortable : false
				},
				{
					property : '_action',
					label : '操作',
					sortable : false
				} 
			];
}

function changeDefaultImg(obj){
	obj.src = STATIC_URL+"/images/logo-default.png";
}

function formatData(items) {
	$.each(items, function(index, item) {
		item._query = '<a href="'+BASE_URL+'/articleContent/detail?contentId=' + item.contentId + '"  class="modal-detail load-content"><i class="fa fa-search-plus" title="查看详情"></i></a>';
		item.image = item.image==null?"":"<img style='width:40px;height:20px;' onerror='changeDefaultImg(this)' src='"+IMG_URL+item.image+"'";
		item.click = '<b class="badge bg-primary">'+item.click+'</b>';
		item.status = item.status==0?'<i class="fa fa-times text-danger text"></i>':'<i class="fa fa-check text-success text"></i>';
		item._action = '<a href="' + BASE_URL + '/articleContent/edit?contentId=' + item.contentId
				+ '" class="operating-edit load-content" title="编辑"><i class="fa fa-pencil"></i></a>&nbsp;&nbsp;'
				+ '<a href="javascript:;" class="operate-delete" id="contentId_' + item.contentId + '" contentId="' + item.contentId
				+ '" title="删除"><i class="fa fa-trash-o"></i></a>';

		item.mtime = dateConverter(item.mtime, PATTERN_ENUM.datetime);
		item.ctime = dateConverter(item.ctime, PATTERN_ENUM.datetime);
	});
}