$(document).ready(function() {
	loadDataGridContent(columnsDefined(), 'formatData');

	/**
	 * 刷新或搜索
	 */
	$('body').delegate('.action-refresh, #action_search', 'click', function() {
		$('#content_listing').datagrid('reload');
	});

	/**
	 * 关键字搜索 - 支持回车
	 */
	$("input[name=key]").on('keypress', function(event) {
		if (event.which == '13') {
			$('#content_listing').datagrid('reload');
			return false;
		}
	});

	/**
	 * 单个删除
	 */
	$('#content_listing').delegate('.operate-delete', 'click', function() {
		var del = confirm('确定要删除吗？');
		if (!del) {
			return false;
		}
		
	var confid = $(this).attr("confid");
		
		/* 执行 */
		$.ajax({
			type : 'post',
			url : BASE_URL + '/trendConf/delete',
			data : 'confid=' + confid,
			dataType : 'json',
			timeout : 10000,
			success : function(data) {
				if (data.status == 0) {
					$("#confid_" + confid).parent().parent().remove();
				} else {
					alert(data.msg);
				}
				return false;
			}
		});
	});
});

function columnsDefined() {
	return [
				{
					property : 'confid',
					label : '配置ID',
					sortable : false
				},
				{
					property : 'confname',
					label : '配置名',
					sortable : false
				},
				{
					property : 'confvalue',
					label : '配置值',
					sortable : false
				},
				{
					property : 'createtime',
					label : '创建时间',
					sortable : false
				},
				{
					property : 'status',
					label : '状态',
					sortable : false
				},
				{
					property : '_action',
					label : '操作',
					sortable : false
				} 
			];
}

function formatData(items) {
	$.each(items, function(index, item) {
		if(item.status==1){
		 item.status = '<span><i class="btn-sm btn-success" >启用</i></span>';	
		}
		else{
		 item.status = '<span><i class="btn-sm btn-dark" >禁用</i></span>';	
		}
		if(item.createtime){
			item.createtime = moment(item.createtime, "YYYYMMDDHHmmss").format("YYYY年MM月DD日 HH:mm:ss");
		}
		item._action = '<a href="' + BASE_URL + '/trendConf/edit?confid=' + item.confid
				+ '" class="operating-edit" title="编辑"><i class="fa fa-pencil"></i></a>&nbsp;&nbsp;'
				+ '<a href="javascript:;" class="operate-delete" id="confid_' + item.confid + '" confid="' + item.confid
				+ '" title="删除"><i class="fa fa-trash-o"></i></a>';

	});
}