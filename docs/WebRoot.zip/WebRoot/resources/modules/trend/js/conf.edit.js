$(document).ready(function() {
	/**
	 * 提交按钮处理
	 */
	$(".input-submit").click(function() {
		var submit_type = $(this).attr("data_submit_type");
		switch (submit_type) {
		case 'submit_cancel':
			form_cancel();
			break;
		case 'submit_save_back':
			back_listing = true;
			form_submit();
			break;
		case 'submit_save_continue':
			back_listing = false;
			form_submit();
			break;
		}
	});
});

/**
 * 表单提交处理
 */
function form_submit() {
	var confid = $("input[name=confid]").val();
	var saveCallBack;
	if (confid == '' || confid == 0) {
		saveCallBack = form_save_added;
	} else {
		saveCallBack = form_save_edited;
	}
	$.ajax_submit( {
		url : $("#edit_form").attr("action"),
		bnt : $(".input-submit"),
		form : $("#edit_form"),
		callback : saveCallBack,
		validate : {
			rules : {
				confname : {
					required : true
				},
				confvalue : {
					required : true
				},
				confdetail : {
					required : true
				}
			},
			messages : {
				confname : {
					required : "请输入配置标题"
				},
				confvalue : {
					required : "请输入配置内容"
				},
				confdetail : {
					required : "请输入配置详情"
				}
			}
		}
	});
	return false;
}

/**
 * 取消处理
 */
function form_cancel() {
	window.location.href = BASE_URL + "/trendConf/index";
}

/**
 * 添加成功，返回处理
 */
function form_save_added(data, textStatus) {
	if (data.status === 0) {
		alert('添加成功!');

		// 判断是否返回列表管理
		if (back_listing == true) {
			form_cancel();
		} else {
			window.location.href = BASE_URL + "/trendConf/add";
		}
	} else {
		alert(data.msg);
	}
}

/**
 * 编辑成功，返回处理
 */
function form_save_edited(data, textStatus) {
	if (data.status === 0) {
		alert('编辑成功!');
		form_cancel();
	} else {
		alert(data.msg);
	}
}