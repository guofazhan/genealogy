$(document).ready(function() {
	loadDataGridContent(columnsDefined(), 'formatData');

	/**
	 * 刷新或搜索
	 */
	$('body').delegate('.action-refresh, #action_search', 'click', function() {
		$('#content_listing').datagrid('reload');
	});

	/**
	 * 关键字搜索 - 支持回车
	 */
	$("input[name=key]").on('keypress', function(event) {
		if (event.which == '13') {
			$('#content_listing').datagrid('reload');
			return false;
		}
	});

	/**
	 * 单个删除
	 */
	$('#content_listing').delegate('.operate-delete', 'click', function() {
		var del = confirm('确定要删除吗？');
		if (!del) {
			return false;
		}

		var productid = $(this).attr("productid");

		/* 执行 */
		$.ajax( {
			type : 'post',
			url : BASE_URL + '/productBase/delete',
			data : 'productid=' + productid,
			dataType : 'json',
			timeout : 10000,
			success : function(data) {
				if (data.status == 0) {
					$("#productid_" + productid).parent().parent().remove();
				} else {
					alert(data.msg);
				}
				return false;
			}
		});
	});
});

function columnsDefined() {
	return [ {
		property : '_query',
		label : ''
	}, {
		property : 'productid',
		label : '产品ID',
		sortable : false
	}, {
		property : 'producticon',
		label : '产品图标',
		sortable : false
	}, {
		property : 'productname',
		label : '产品名称',
		sortable : false
	}, {
		property : 'productversion',
		label : '版本号',
		sortable : false
	}, {
		property : 'status',
		label : '状态',
		sortable : false
	},

	{
		property : 'producttypename',
		label : '产品类型',
		sortable : false
	}, {
		property : 'downloadcount',
		label : '下载次数',
		sortable : false
	}, {
		property : 'systemtype',
		label : '系统类型',
		sortable : false
	}, {
		property : 'ctime',
		label : '创建时间',
		sortable : false
	}, {
		property : 'cuser',
		label : '创建用户',
		sortable : false
	}, {
		property : '_action',
		label : '操作',
		sortable : false
	} ];
}

function formatData(items) {
	$
			.each(
					items,
					function(index, item) {
						item._query = '<a href="'
								+ BASE_URL
								+ '/productBase/detail?productid='
								+ item.productid
								+ '"  class="modal-detail"><i class="fa fa-search-plus" title="查看详情"></i></a>';

						if (item.producticon != null) {
							item.producticon = '<img width="25px" height="25px" src="'
									+ IMG_URL + "/" + item.producticon + '">';
						} else {
							item.producticon = '';
						}

						if (item.status == 1) {
							item.status = '<i class="btn-sm btn-info">已发布</i>';
						} else {
							item.status = '<i class="btn-sm btn-dark">隐藏</i>';
						}
						if (item.ctime) {
							item.ctime = moment(item.ctime,
									"YYYYMMDDHHmmss").format(
									"YYYY年MM月DD日 HH:mm:ss");
						}
						item._action = '<a href="'
								+ BASE_URL
								+ '/productBase/edit?productid='
								+ item.productid
								+ '" class="operating-edit" title="编辑"><i class="fa fa-pencil"></i></a>&nbsp;&nbsp;'
								+ '<a href="javascript:;" class="operate-delete" id="productid_'
								+ item.productid
								+ '" productid="'
								+ item.productid
								+ '" title="删除"><i class="fa fa-trash-o"></i></a>';

					});
}