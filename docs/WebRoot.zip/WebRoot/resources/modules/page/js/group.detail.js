$(document).ready(function() {
    /**
	 * 返回
	 */
    $("#button_cancel").click(function(){
    	window.location.href = BASE_URL+"/pageGroup/index";
	});
});