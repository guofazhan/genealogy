﻿$(document).ready(function() {
	loadDataGridContent(columnsDefined(), 'formatData');

	/**
	 * 刷新或搜索
	 */
	$('body').delegate('.action-refresh, #action_search', 'click', function() {
		$('#content_listing').datagrid('reload');
	});

	/**
	 * 关键字搜索 - 支持回车
	 */
	$("input[name=key]").on('keypress', function(event) {
		if (event.which == '13') {
			$('#content_listing').datagrid('reload');
			return false;
		}
	});

	/**
	 * 单个删除
	 */
	$('#content_listing').delegate('.operate-delete', 'click', function() {
		var del = confirm('确定要删除吗？');
		if (!del) {
			return false;
		}
		
				var groupId = $(this).attr("groupId");
		
		/* 执行 */
		$.ajax({
			type : 'post',
			url : BASE_URL + '/pageGroup/delete',
			data : 'groupId=' + groupId,
			dataType : 'json',
			timeout : 10000,
			success : function(data) {
				if (data.status == 0) {
					$("#groupId_" + groupId).parent().parent().remove();
				} else {
					alert(data.msg);
				}
				return false;
			}
		});
	});
});

function columnsDefined() {
	return [
				/*{
					property: '_query',
					label: ''
				},*/
				{
					property : 'groupId',
					label : '单页分组ID',
					sortable : false
				},
				/*{
					property : 'folder',
					label : '',
					sortable : false
				},*/
				{
					property : 'groupName',
					label : '分组名称',
					sortable : false
				},
			/*	{
					property : 'moveable',
					label : '是否允许被删除',
					sortable : false
				},
				{
					property : 'sortOrder',
					label : '',
					sortable : false
				},*/
				{
					property : '_action',
					label : '操作',
					sortable : false
				} 
			];
}

function formatData(items) {
	$.each(items, function(index, item) {
		item._query = '<a href="'+BASE_URL+'/pageGroup/detail?groupId=' + item.groupId + '"  class="modal-detail"><i class="fa fa-search-plus" title="查看详情"></i></a>';
		item._action = '<a href="' + BASE_URL + '/pageGroup/edit?groupId=' + item.groupId
				+ '" class="operating-edit" title="编辑"><i class="fa fa-pencil"></i></a>&nbsp;&nbsp;'
				+ '<a href="javascript:;" class="operate-delete" id="groupId_' + item.groupId + '" groupId="' + item.groupId
				+ '" title="删除"><i class="fa fa-trash-o"></i></a>';

	});
}